<?php

namespace App\Http\Controllers;

use Illuminate\Support\Arr;
use Illuminate\Http\Request;
use App\Models\TbUser;

class UsersController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $users = TbUser::all();
    return response()->json($users);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function login(Request $request) {
    $email = $request->query('email');
    $password = $request->query('password');

    if ($email && $password) {
        $user = TbUser::where('email', $email)->first();

        if ($user && $user->password == $password) {
            // Ocultar el password en la respuesta
            $userArray = $user->toArray();
            unset($userArray['password']);
            return response()->json($userArray);
        } else {
            return response()->json(['message' => 'Invalid credentials'], 401);
        }
    }

    return response()->json(['message' => 'Email and password are required'], 400);
}
}
